package com.example.lagdrop.net

import android.util.Log
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.SelectionKey
import java.nio.channels.SocketChannel
import kotlin.random.Random

private const val MASK = 0xFFFFFFFFL
private fun seqLt(a: Long, b: Long) = (a - b).toInt() < 0
private fun seqGt(a: Long, b: Long) = (a - b).toInt() > 0
private fun seqGeq(a: Long, b: Long) = (a - b).toInt() >= 0
private fun seqLeq(a: Long, b: Long) = (a - b).toInt() <= 0

/**
 * Локальная терминация TCP. Приложение общается с нами как с сервером; мы открываем
 * настоящий сокет к цели. Ретрансмиссии в сторону приложения нет сознательно: пакеты
 * в tun не теряются, а переполнение исключено, потому что мы не шлём больше окна клиента.
 * Входящий дроп для TCP поэтому реализован как пауза чтения из серверного сокета
 * (данные ждут в буфере ядра), а не как потеря сегмента.
 *
 * Только из worker-потока.
 */
class TcpRelay(private val engine: TunnelEngine) {

    private data class ConnKey(val cIp: Int, val cPort: Int, val sIp: Int, val sPort: Int)

    class Conn internal constructor(
        internal val key: Any,
        val cIp: Int, val cPort: Int, val sIp: Int, val sPort: Int,
        val chan: SocketChannel,
    ) {
        var selKey: SelectionKey? = null
        var established = false
        var synAcked = false
        var closed = false

        var clientIsn = 0L
        var ourIsn = 0L
        var clientNext = 0L
        var ourSeq = 0L
        var clientAcked = 0L
        var clientWindow = 0
        var segSize = 536

        val pending = ArrayDeque<ByteBuffer>()
        var pendingBytes = 0
        var lastAdvWindow = 65535

        var clientFin = false
        var shutOutDone = false
        var serverEof = false
        var finSent = false
        var finAcked = false

        var readEnabled = false
        var blockedByWindow = true

        val createdNanos = System.nanoTime()
        var lastNanos = createdNanos
    }

    private val conns = HashMap<Any, Conn>()
    private val readBuf = ByteBuffer.allocate(2048)

    fun onSegment(seg: TcpSegment) {
        val ip = seg.ip
        val k = ConnKey(ip.src, seg.srcPort, ip.dst, seg.dstPort)
        val c = conns[k]

        if (seg.has(Tcp.SYN) && !seg.has(Tcp.ACK)) {
            onSyn(k, seg, c)
            return
        }
        if (c == null) {
            if (!seg.has(Tcp.RST)) resetFor(seg)
            return
        }
        c.lastNanos = System.nanoTime()
        if (seg.has(Tcp.RST)) {
            close(c)
            return
        }
        if (!c.established) return

        if (seg.has(Tcp.ACK)) onAck(c, seg)
        if (c.closed) return
        if (c.synAcked) onClientData(c, seg)
    }

    private fun onSyn(k: ConnKey, seg: TcpSegment, existing: Conn?) {
        if (existing != null) {
            // Ретрансмит SYN: наш SYN-ACK мог быть потерян (в том числе дропом).
            if (existing.established && !existing.synAcked && seg.seq == existing.clientIsn) {
                sendSynAck(existing)
            }
            return
        }
        if (conns.size >= MAX_CONNS) {
            resetFor(seg)
            return
        }
        val ip = seg.ip
        var ch: SocketChannel? = null
        try {
            ch = SocketChannel.open()
            if (!engine.protector.tcp(ch.socket())) throw IOException("protect() вернул false")
            ch.configureBlocking(false)
            ch.socket().tcpNoDelay = true

            val c = Conn(k, ip.src, seg.srcPort, ip.dst, seg.dstPort, ch)
            c.clientIsn = seg.seq
            c.clientNext = (seg.seq + 1) and MASK
            c.ourIsn = Random.nextLong() and MASK
            c.clientAcked = c.ourIsn
            c.clientWindow = seg.window
            val mss = seg.mssOption().let { if (it == 0) 536 else it }
            c.segSize = minOf(mss, engine.mtu - 40)
            conns[k] = c

            val addr = InetSocketAddress(InetAddress.getByAddress(UdpRelay.addr(ip.dst)), seg.dstPort)
            if (ch.connect(addr)) {
                onConnected(c)
            } else {
                c.selKey = ch.register(engine.selector, SelectionKey.OP_CONNECT, c)
            }
        } catch (e: Exception) {
            Log.w(TAG, "tcp connect setup failed", e)
            conns.remove(k)
            runCatching { ch?.close() }
            resetFor(seg)
        }
    }

    fun onReady(key: SelectionKey, c: Conn) {
        try {
            if (key.isValid && key.isConnectable) {
                if (c.chan.finishConnect()) onConnected(c)
                return
            }
            if (key.isValid && key.isWritable) flushToServer(c)
            if (!c.closed && key.isValid && key.isReadable) pump(c)
        } catch (e: IOException) {
            resetClient(c)
        }
    }

    private fun onConnected(c: Conn) {
        c.established = true
        c.ourSeq = (c.ourIsn + 1) and MASK
        if (c.selKey == null) c.selKey = c.chan.register(engine.selector, 0, c)
        updateInterest(c)
        sendSynAck(c)
    }

    private fun sendSynAck(c: Conn) {
        // Единственный пакет, который при входящем дропе реально теряется: клиент
        // повторит SYN (через ~1 с) и получит ответ. Остальное TCP-управление не теряем.
        if (engine.gate.dropInbound()) return
        engine.writeTun(
            PacketBuilder.tcp(
                c.sIp, c.cIp, c.sPort, c.cPort, c.ourIsn, c.clientNext,
                Tcp.SYN or Tcp.ACK, RECV_WINDOW, mss = engine.mtu - 40,
            )
        )
    }

    private fun onAck(c: Conn, seg: TcpSegment) {
        val ack = seg.ack
        if (seqGt(ack, c.clientAcked) && seqLeq(ack, c.ourSeq)) c.clientAcked = ack
        if (!c.synAcked && seqGeq(c.clientAcked, (c.ourIsn + 1) and MASK)) c.synAcked = true
        if (!c.synAcked) return
        c.clientWindow = seg.window
        if (c.finSent && c.clientAcked == c.ourSeq) c.finAcked = true
        if (c.blockedByWindow) pump(c)
        closeIfDone(c)
    }

    private fun onClientData(c: Conn, seg: TcpSegment) {
        val len = seg.payloadLen
        var off = seg.payloadOff
        var n = len
        var seq = seg.seq
        val expected = c.clientNext

        if (n > 0 && seqLt(seq, expected)) {
            val skip = ((expected - seq) and MASK).toInt()
            if (skip >= n) {
                n = 0
            } else {
                off += skip
                n -= skip
                seq = expected
            }
        }
        if (n > 0 && seq == expected && c.pendingBytes + n <= MAX_PENDING) {
            c.pending.addLast(ByteBuffer.wrap(seg.ip.buf.copyOfRange(off, off + n)))
            c.pendingBytes += n
            c.clientNext = (expected + n) and MASK
            flushToServer(c)
            if (c.closed) return
        }
        // Остальные случаи (дубликат, вне порядка, переполнение) отвечаем текущим ACK,
        // клиент сам ретранслирует недостающее.

        if (seg.has(Tcp.FIN) && !c.clientFin && ((seg.seq + len) and MASK) == c.clientNext) {
            c.clientFin = true
            c.clientNext = (c.clientNext + 1) and MASK
            maybeShutdownOutput(c)
        }
        if (len > 0 || seg.has(Tcp.FIN)) sendAck(c)
        closeIfDone(c)
    }

    private fun flushToServer(c: Conn) {
        try {
            while (true) {
                val b = c.pending.firstOrNull() ?: break
                val w = c.chan.write(b)
                c.pendingBytes -= w
                if (b.hasRemaining()) break
                c.pending.removeFirst()
            }
        } catch (e: IOException) {
            resetClient(c)
            return
        }
        maybeShutdownOutput(c)
        updateInterest(c)
        // Окно, которое мы объявляли, могло сжаться почти до нуля: сообщаем, что место появилось.
        if (c.pending.isEmpty() && c.lastAdvWindow < 8192 && c.synAcked) sendAck(c)
    }

    private fun maybeShutdownOutput(c: Conn) {
        if (c.clientFin && c.pending.isEmpty() && !c.shutOutDone) {
            c.shutOutDone = true
            try {
                c.chan.shutdownOutput()
            } catch (e: IOException) {
                // сокет уже закрыт с той стороны — нечего делать
            }
        }
    }

    private fun pump(c: Conn) {
        if (c.closed || !c.synAcked) return
        if (engine.gate.dropInbound()) {
            engine.gate.tcpPaused.incrementAndGet()
            c.readEnabled = false
            c.blockedByWindow = true
            updateInterest(c)
            return
        }
        var wantRead = !c.serverEof
        var blocked = false
        try {
            while (!c.serverEof) {
                val inflight = (c.ourSeq - c.clientAcked) and MASK
                val room = c.clientWindow - inflight
                if (room <= 0) {
                    blocked = true
                    wantRead = false
                    break
                }
                val n = minOf(room, c.segSize.toLong()).toInt()
                readBuf.clear()
                readBuf.limit(n)
                val r = c.chan.read(readBuf)
                if (r < 0) {
                    c.serverEof = true
                    sendFin(c)
                    wantRead = false
                    break
                }
                if (r == 0) break
                engine.writeTun(
                    PacketBuilder.tcp(
                        c.sIp, c.cIp, c.sPort, c.cPort, c.ourSeq, c.clientNext,
                        Tcp.PSH or Tcp.ACK, advWindow(c), readBuf.array(), 0, r,
                    )
                )
                c.ourSeq = (c.ourSeq + r) and MASK
                c.lastNanos = System.nanoTime()
            }
        } catch (e: IOException) {
            resetClient(c)
            return
        }
        c.readEnabled = wantRead
        c.blockedByWindow = blocked
        updateInterest(c)
        closeIfDone(c)
    }

    fun resumeAll() {
        for (c in conns.values.toList()) {
            try {
                pump(c)
            } catch (e: Exception) {
                Log.w(TAG, "resume failed", e)
            }
        }
    }

    fun resetAll() {
        for (c in conns.values.toList()) {
            try {
                resetClient(c)
            } catch (e: Exception) {
                Log.w(TAG, "reset failed", e)
            }
        }
    }

    private fun sendFin(c: Conn) {
        if (c.finSent) return
        engine.writeTun(
            PacketBuilder.tcp(
                c.sIp, c.cIp, c.sPort, c.cPort, c.ourSeq, c.clientNext,
                Tcp.FIN or Tcp.ACK, advWindow(c),
            )
        )
        c.ourSeq = (c.ourSeq + 1) and MASK
        c.finSent = true
    }

    private fun sendAck(c: Conn) {
        val w = advWindow(c)
        c.lastAdvWindow = w
        engine.writeTun(
            PacketBuilder.tcp(c.sIp, c.cIp, c.sPort, c.cPort, c.ourSeq, c.clientNext, Tcp.ACK, w)
        )
    }

    private fun advWindow(c: Conn): Int = (RECV_WINDOW - c.pendingBytes).coerceIn(0, RECV_WINDOW)

    private fun updateInterest(c: Conn) {
        val k = c.selKey ?: return
        if (!k.isValid) return
        var ops = 0
        if (!c.established) {
            ops = SelectionKey.OP_CONNECT
        } else {
            if (c.readEnabled) ops = ops or SelectionKey.OP_READ
            if (c.pending.isNotEmpty()) ops = ops or SelectionKey.OP_WRITE
        }
        k.interestOps(ops)
    }

    private fun closeIfDone(c: Conn) {
        if (!c.closed && c.clientFin && c.serverEof && c.finSent && c.finAcked) close(c)
    }

    private fun resetClient(c: Conn) {
        if (!c.closed) {
            val seq = if (c.established) c.ourSeq else 0L
            engine.writeTun(
                PacketBuilder.tcp(c.sIp, c.cIp, c.sPort, c.cPort, seq, c.clientNext, Tcp.RST or Tcp.ACK, 0)
            )
        }
        close(c)
    }

    private fun resetFor(seg: TcpSegment) {
        val ip = seg.ip
        val pkt = if (seg.has(Tcp.ACK)) {
            PacketBuilder.tcp(ip.dst, ip.src, seg.dstPort, seg.srcPort, seg.ack, 0, Tcp.RST, 0)
        } else {
            var ackNum = seg.seq + seg.payloadLen
            if (seg.has(Tcp.SYN)) ackNum++
            if (seg.has(Tcp.FIN)) ackNum++
            PacketBuilder.tcp(
                ip.dst, ip.src, seg.dstPort, seg.srcPort, 0, ackNum and MASK, Tcp.RST or Tcp.ACK, 0,
            )
        }
        engine.writeTun(pkt)
    }

    private fun close(c: Conn) {
        if (c.closed) return
        c.closed = true
        conns.remove(c.key)
        c.selKey?.cancel()
        runCatching { c.chan.close() }
    }

    fun sweep(now: Long) {
        for (c in conns.values.toList()) {
            val idle = now - c.lastNanos
            when {
                !c.established && now - c.createdNanos > CONNECT_TIMEOUT_NANOS -> resetClient(c)
                (c.clientFin || c.serverEof) && idle > HALF_CLOSED_NANOS -> resetClient(c)
                idle > IDLE_NANOS -> resetClient(c)
            }
        }
    }

    fun closeAll() {
        for (c in conns.values.toList()) close(c)
    }

    companion object {
        private const val TAG = "LagDrop"
        private const val RECV_WINDOW = 65535 // без window scaling: опцию в SYN-ACK не отправляем
        private const val MAX_PENDING = 256 * 1024
        private const val MAX_CONNS = 1024
        private const val CONNECT_TIMEOUT_NANOS = 20_000_000_000L
        private const val HALF_CLOSED_NANOS = 60_000_000_000L
        private const val IDLE_NANOS = 15 * 60_000_000_000L
    }
}
