package com.example.lagdrop

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Флаг дропа читается из потоков движка, поэтому он на nanoTime и volatile,
 * а не на Handler: корректность окна не зависит от того, что main-поток не завис.
 */
class DropGate {
    @Volatile private var untilNanos: Long = System.nanoTime() - 1_000_000_000L
    @Volatile private var both: Boolean = false

    private fun active(): Boolean = System.nanoTime() - untilNanos < 0

    fun dropOutbound(): Boolean = active()
    fun dropInbound(): Boolean = both && active()

    fun start(windowMs: Long, bothDirections: Boolean) {
        both = bothDirections
        untilNanos = System.nanoTime() + windowMs * 1_000_000L
    }

    fun stop() {
        untilNanos = System.nanoTime() - 1L
    }

    fun isActive(): Boolean = active()
}

/** Все публичные методы — только с main-потока (кнопка, уведомление, таймер). */
object DropController {
    val gate = DropGate()

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<(Boolean) -> Unit>()
    private val endRunnable = Runnable { cancel() }

    // Выставляется сервисом: после окна надо разбудить движок, чтобы он
    // доставил удержанные входящие TCP-данные.
    @Volatile var onWindowEnd: (() -> Unit)? = null

    fun addListener(l: (Boolean) -> Unit) { listeners.add(l) }
    fun removeListener(l: (Boolean) -> Unit) { listeners.remove(l) }

    fun isActive(): Boolean = gate.isActive()

    fun toggle(prefs: Prefs) {
        if (gate.isActive()) {
            cancel()
            return
        }
        val ms = prefs.windowMs.toLong()
        gate.start(ms, prefs.direction == DropDirection.BOTH)
        main.postDelayed(endRunnable, ms)
        listeners.forEach { it(true) }
    }

    fun cancel() {
        main.removeCallbacks(endRunnable)
        gate.stop()
        onWindowEnd?.invoke()
        // Слушателям сообщаем всегда: кнопка должна гарантированно вернуть цвет.
        listeners.forEach { it(false) }
    }
}
