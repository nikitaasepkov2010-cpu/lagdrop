package com.example.lagdrop.net

import android.util.Log
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.nio.channels.SelectionKey

/** Только из worker-потока. */
class UdpRelay(private val engine: TunnelEngine) {

    private data class FlowKey(val src: Int, val sPort: Int, val dst: Int, val dPort: Int)

    class Flow internal constructor(
        internal val key: Any,
        val chan: DatagramChannel,
        val src: Int, val sPort: Int, val dst: Int, val dPort: Int,
    ) {
        var lastNanos = System.nanoTime()
    }

    private val flows = HashMap<Any, Flow>()
    private val readBuf = ByteBuffer.allocate(65535)

    fun onDatagram(dg: UdpDatagram) {
        val ip = dg.ip
        if (isMulticastOrBroadcast(ip.dst)) return
        val k = FlowKey(ip.src, dg.srcPort, ip.dst, dg.dstPort)
        var flow = flows[k]
        if (flow == null) {
            if (flows.size >= MAX_FLOWS) return
            flow = open(k, dg) ?: return
            flows[k] = flow
        }
        flow.lastNanos = System.nanoTime()
        try {
            flow.chan.write(ByteBuffer.wrap(ip.buf, dg.payloadOff, dg.payloadLen))
        } catch (e: IOException) {
            // PortUnreachable и т.п. — закрываем поток, приложение пересоздаст.
            close(flow)
        }
    }

    private fun open(k: FlowKey, dg: UdpDatagram): Flow? {
        var ch: DatagramChannel? = null
        try {
            ch = DatagramChannel.open()
            if (!engine.protector.udp(ch.socket())) {
                ch.close()
                return null
            }
            ch.configureBlocking(false)
            ch.connect(InetSocketAddress(InetAddress.getByAddress(addr(k.dst)), k.dPort))
            val flow = Flow(k, ch, k.src, k.sPort, k.dst, k.dPort)
            ch.register(engine.selector, SelectionKey.OP_READ, flow)
            return flow
        } catch (e: Exception) {
            Log.w("LagDrop", "udp open failed", e)
            runCatching { ch?.close() }
            return null
        }
    }

    fun onReady(flow: Flow) {
        var budget = 16
        while (budget-- > 0) {
            readBuf.clear()
            val n = try {
                flow.chan.read(readBuf)
            } catch (e: IOException) {
                close(flow)
                return
            }
            if (n < 0) { close(flow); return }
            if (n == 0) return
            flow.lastNanos = System.nanoTime()
            // Входящий UDP при дропе реально теряется (в отличие от TCP).
            if (engine.gate.dropInbound()) continue
            engine.writeTun(
                PacketBuilder.udp(flow.dst, flow.src, flow.dPort, flow.sPort, readBuf.array(), n)
            )
        }
    }

    fun sweep(now: Long) {
        val dead = flows.values.filter { now - it.lastNanos > IDLE_NANOS }
        dead.forEach { close(it) }
    }

    fun closeAll() {
        flows.values.toList().forEach { close(it) }
    }

    private fun close(f: Flow) {
        flows.remove(f.key)
        runCatching { f.chan.close() }
    }

    private fun isMulticastOrBroadcast(ip: Int): Boolean {
        val first = ip ushr 24
        return first in 224..239 || ip == -1
    }

    companion object {
        private const val MAX_FLOWS = 1024
        private const val IDLE_NANOS = 60_000_000_000L

        fun addr(ip: Int): ByteArray = byteArrayOf(
            (ip ushr 24).toByte(), (ip ushr 16).toByte(), (ip ushr 8).toByte(), ip.toByte()
        )
    }
}
