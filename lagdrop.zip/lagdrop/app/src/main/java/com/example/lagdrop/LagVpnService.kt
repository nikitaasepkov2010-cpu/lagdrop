package com.example.lagdrop

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.lagdrop.net.Protector
import com.example.lagdrop.net.TunnelEngine
import java.net.DatagramSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList

/** Состояние для UI. Слушатели вызываются на main-потоке. */
object TunnelState {
    @Volatile var running = false
        private set
    @Volatile var error: String? = null
        private set

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun update(running: Boolean, error: String?) {
        this.running = running
        this.error = error
        main.post { listeners.forEach { it() } }
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
}

class LagVpnService : VpnService() {

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())

    private var tun: ParcelFileDescriptor? = null
    private var engine: TunnelEngine? = null
    private var overlay: OverlayButton? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.wantRunning = false
                shutdown(null)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                if (engine != null) DropController.toggle(prefs) else stopSelf()
                return if (engine != null) START_STICKY else START_NOT_STICKY
            }
            else -> {
                // Первым делом: после startForegroundService() на это даётся ~5 секунд.
                promoteToForeground()
                // intent == null — системный перезапуск после убийства процесса.
                if (intent == null && !prefs.wantRunning) {
                    shutdown(null)
                    stopSelf()
                    return START_NOT_STICKY
                }
                startTunnel()
                return if (engine != null) START_STICKY else START_NOT_STICKY
            }
        }
    }

    override fun onRevoke() {
        // Пользователь запустил другой VPN или отозвал разрешение: tun уже закрыт системой.
        prefs.wantRunning = false
        shutdown(getString(R.string.err_revoked))
        super.onRevoke() // вызывает stopSelf()
    }

    override fun onDestroy() {
        if (engine != null || tun != null || overlay != null) shutdown(null)
        super.onDestroy()
    }

    private fun startTunnel() {
        if (engine != null) return
        TunnelState.update(false, null)

        if (prepare(this) != null) {
            fail(getString(R.string.err_consent_revoked))
            return
        }

        val pfd = establishTun()
        if (pfd == null) {
            fail(getString(R.string.err_establish))
            return
        }
        tun = pfd

        val eng = TunnelEngine(
            tunFd = pfd.fileDescriptor,
            mtu = MTU,
            protector = Protector(
                tcp = { s: Socket -> protect(s) },
                udp = { s: DatagramSocket -> protect(s) },
            ),
            gate = DropController.gate,
            onFatal = { t ->
                Log.e(TAG, "движок остановился", t)
                main.post {
                    if (engine != null) {
                        prefs.wantRunning = false
                        fail(getString(R.string.err_engine, t.message ?: t.javaClass.simpleName))
                    }
                }
            },
        )
        engine = eng
        DropController.onWindowEnd = { eng.resume() }
        eng.start()

        var overlayShown = false
        if (Settings.canDrawOverlays(this)) {
            try {
                overlay = OverlayButton(this, prefs).also { it.show() }
                overlayShown = true
            } catch (e: Exception) {
                Log.w(TAG, "overlay не показан", e)
                overlay = null
            }
        }

        prefs.wantRunning = true
        TunnelState.update(true, null)
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(overlayShown))
    }

    private fun establishTun(): ParcelFileDescriptor? {
        // IPv6-маршрут без IPv6-адреса: v6-соединения сразу получают ENETUNREACH и приложения
        // уходят на IPv4 (через наш релей), а не обходят дроп напрямую по v6.
        for (withV6 in listOf(true, false)) {
            try {
                val b = Builder()
                    .setSession("LagDrop")
                    .setMtu(MTU)
                    .addAddress("10.77.0.2", 32)
                    .addRoute("0.0.0.0", 0)
                if (withV6) b.addRoute("::", 0)
                // Иначе собственные сокеты приложения зациклились бы в туннель; protect() страхует.
                runCatching { b.addDisallowedApplication(packageName) }
                if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
                b.establish()?.let { return it }
            } catch (e: Exception) {
                Log.w(TAG, "establish(withV6=$withV6) не удался", e)
            }
        }
        return null
    }

    private fun fail(message: String) {
        prefs.wantRunning = false
        shutdown(message)
        stopSelf()
    }

    private fun shutdown(error: String?) {
        DropController.onWindowEnd = null
        DropController.cancel()
        overlay?.hide()
        overlay = null
        engine?.stop()
        engine = null
        runCatching { tun?.close() }
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        TunnelState.update(false, error)
    }

    private fun promoteToForeground() {
        val n = buildNotification(Settings.canDrawOverlays(this))
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(overlayShown: Boolean) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(
                getString(if (overlayShown) R.string.notif_text_overlay else R.string.notif_text_no_overlay)
            )
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
            )
            .addAction(0, getString(R.string.notif_action_drop), servicePendingIntent(1, ACTION_TOGGLE))
            .addAction(0, getString(R.string.notif_action_stop), servicePendingIntent(2, ACTION_STOP))
            .build()

    private fun servicePendingIntent(code: Int, action: String): PendingIntent =
        PendingIntent.getService(
            this, code, Intent(this, LagVpnService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    companion object {
        const val ACTION_START = "com.example.lagdrop.START"
        const val ACTION_STOP = "com.example.lagdrop.STOP"
        const val ACTION_TOGGLE = "com.example.lagdrop.TOGGLE"

        private const val TAG = "LagDrop"
        private const val CHANNEL_ID = "tunnel"
        private const val NOTIF_ID = 1
        private const val MTU = 1500
    }
}
