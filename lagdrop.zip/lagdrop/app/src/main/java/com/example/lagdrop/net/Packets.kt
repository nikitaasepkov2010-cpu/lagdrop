package com.example.lagdrop.net

/** Разбор и сборка IPv4/TCP/UDP. Адреса хранятся Int в сетевом порядке байт. */
object Ip {
    const val PROTO_TCP = 6
    const val PROTO_UDP = 17
}

object Tcp {
    const val FIN = 0x01
    const val SYN = 0x02
    const val RST = 0x04
    const val PSH = 0x08
    const val ACK = 0x10
}

class IpPacket private constructor(val buf: ByteArray, val len: Int) {
    val ihl: Int = (buf[0].toInt() and 0x0F) * 4
    val protocol: Int = buf[9].toInt() and 0xFF
    val totalLen: Int = u16(2)
    val src: Int = i32(12)
    val dst: Int = i32(16)

    /** Начало транспортного заголовка. */
    val l4: Int get() = ihl

    fun u8(o: Int): Int = buf[o].toInt() and 0xFF
    fun u16(o: Int): Int = (u8(o) shl 8) or u8(o + 1)
    fun i32(o: Int): Int = (u8(o) shl 24) or (u8(o + 1) shl 16) or (u8(o + 2) shl 8) or u8(o + 3)
    fun u32(o: Int): Long = i32(o).toLong() and 0xFFFFFFFFL

    companion object {
        /** null — не IPv4, битый, фрагментированный или обрезанный пакет. */
        fun parse(buf: ByteArray, len: Int): IpPacket? {
            if (len < 20 || (buf[0].toInt() ushr 4) != 4) return null
            val ihl = (buf[0].toInt() and 0x0F) * 4
            if (ihl < 20 || len < ihl) return null
            val total = ((buf[2].toInt() and 0xFF) shl 8) or (buf[3].toInt() and 0xFF)
            if (total < ihl || total > len) return null
            val fragField = ((buf[6].toInt() and 0x3F) shl 8) or (buf[7].toInt() and 0xFF)
            if (fragField != 0) return null // MF или offset != 0; DF-бит маской отброшен
            return IpPacket(buf, len)
        }
    }
}

class TcpSegment(val ip: IpPacket) {
    private val o = ip.l4
    val srcPort: Int = ip.u16(o)
    val dstPort: Int = ip.u16(o + 2)
    val seq: Long = ip.u32(o + 4)
    val ack: Long = ip.u32(o + 8)
    private val dataOff: Int = (ip.u8(o + 12) ushr 4) * 4
    val flags: Int = ip.u8(o + 13)
    val window: Int = ip.u16(o + 14)
    val payloadOff: Int = o + dataOff
    val payloadLen: Int = ip.totalLen - ip.ihl - dataOff
    val valid: Boolean = dataOff >= 20 && payloadLen >= 0

    fun has(flag: Int) = flags and flag != 0

    /** MSS из опций SYN, 0 если опции нет. */
    fun mssOption(): Int {
        var p = o + 20
        val end = o + dataOff
        while (p < end) {
            when (val kind = ip.u8(p)) {
                0 -> return 0
                1 -> p++
                else -> {
                    if (p + 1 >= end) return 0
                    val l = ip.u8(p + 1)
                    if (l < 2) return 0
                    if (kind == 2 && l == 4 && p + 3 < end) return ip.u16(p + 2)
                    p += l
                }
            }
        }
        return 0
    }
}

class UdpDatagram(val ip: IpPacket) {
    private val o = ip.l4
    val srcPort: Int = ip.u16(o)
    val dstPort: Int = ip.u16(o + 2)
    val payloadOff: Int = o + 8
    val payloadLen: Int = ip.u16(o + 4) - 8
    val valid: Boolean = payloadLen >= 0 && payloadOff + payloadLen <= ip.totalLen
}

object PacketBuilder {
    private var ipId = 0

    fun tcp(
        src: Int, dst: Int, srcPort: Int, dstPort: Int,
        seq: Long, ack: Long, flags: Int, window: Int,
        payload: ByteArray? = null, payloadOff: Int = 0, payloadLen: Int = 0,
        mss: Int = 0,
    ): ByteArray {
        val tcpHdr = if (mss > 0) 24 else 20
        val tcpLen = tcpHdr + payloadLen
        val out = ByteArray(20 + tcpLen)
        writeIpHeader(out, out.size, Ip.PROTO_TCP, src, dst)
        val o = 20
        put16(out, o, srcPort)
        put16(out, o + 2, dstPort)
        put32(out, o + 4, seq)
        put32(out, o + 8, ack)
        out[o + 12] = ((tcpHdr / 4) shl 4).toByte()
        out[o + 13] = flags.toByte()
        put16(out, o + 14, window.coerceIn(0, 0xFFFF))
        if (mss > 0) {
            out[o + 20] = 2
            out[o + 21] = 4
            put16(out, o + 22, mss)
        }
        if (payloadLen > 0 && payload != null) {
            System.arraycopy(payload, payloadOff, out, o + tcpHdr, payloadLen)
        }
        val sum = checksum(out, o, tcpLen, pseudo(src, dst, Ip.PROTO_TCP, tcpLen))
        put16(out, o + 16, sum)
        return out
    }

    fun udp(
        src: Int, dst: Int, srcPort: Int, dstPort: Int,
        payload: ByteArray, payloadLen: Int,
    ): ByteArray {
        val udpLen = 8 + payloadLen
        val out = ByteArray(20 + udpLen)
        writeIpHeader(out, out.size, Ip.PROTO_UDP, src, dst)
        val o = 20
        put16(out, o, srcPort)
        put16(out, o + 2, dstPort)
        put16(out, o + 4, udpLen)
        System.arraycopy(payload, 0, out, o + 8, payloadLen)
        var sum = checksum(out, o, udpLen, pseudo(src, dst, Ip.PROTO_UDP, udpLen))
        if (sum == 0) sum = 0xFFFF // 0 в UDP означает «без контрольной суммы»
        put16(out, o + 6, sum)
        return out
    }

    private fun writeIpHeader(out: ByteArray, total: Int, proto: Int, src: Int, dst: Int) {
        out[0] = 0x45
        put16(out, 2, total)
        put16(out, 4, ipId++ and 0xFFFF)
        put16(out, 6, 0x4000) // DF
        out[8] = 64
        out[9] = proto.toByte()
        put32(out, 12, src.toLong() and 0xFFFFFFFFL)
        put32(out, 16, dst.toLong() and 0xFFFFFFFFL)
        put16(out, 10, checksum(out, 0, 20, 0))
    }

    private fun pseudo(src: Int, dst: Int, proto: Int, len: Int): Long =
        ((src ushr 16) + (src and 0xFFFF) + (dst ushr 16) + (dst and 0xFFFF) + proto + len).toLong()

    fun checksum(buf: ByteArray, off: Int, len: Int, initial: Long): Int {
        var sum = initial
        var i = off
        val end = off + len
        while (i + 1 < end) {
            sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < end) sum += (buf[i].toInt() and 0xFF) shl 8
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun put16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 8).toByte()
        b[o + 1] = v.toByte()
    }

    private fun put32(b: ByteArray, o: Int, v: Long) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }
}
