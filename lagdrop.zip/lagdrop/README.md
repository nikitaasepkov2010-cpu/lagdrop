# LagDrop

Локальный VpnService (без удалённого сервера) + плавающая кнопка, дропающая трафик на N мс.

Сборка: Android Studio Iguana+ (JDK 17) → Open → Run, либо `./gradlew assembleDebug`
(нужен Android SDK 34; путь задаётся в `local.properties`: `sdk.dir=...`).

Структура:
- `LagVpnService` — tun, foreground-уведомление, onRevoke, перезапуск после убийства системой
- `net/TunnelEngine` — чтение tun (reader-поток, исходящий дроп) и релей (worker-поток)
- `net/TcpRelay`, `net/UdpRelay` — пользовательский «NAT» в protect()-нутые сокеты
- `DropController` — флаг окна дропа и таймер; `OverlayButton` — плавающая кнопка
