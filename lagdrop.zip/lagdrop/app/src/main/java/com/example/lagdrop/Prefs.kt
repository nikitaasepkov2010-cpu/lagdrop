package com.example.lagdrop

import android.content.Context
import android.content.SharedPreferences

enum class DropDirection { OUTGOING, BOTH }

class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("lagdrop", Context.MODE_PRIVATE)

    var windowMs: Int
        get() = sp.getInt(KEY_WINDOW, DEFAULT_WINDOW_MS).coerceIn(MIN_WINDOW_MS, MAX_WINDOW_MS)
        set(v) = sp.edit().putInt(KEY_WINDOW, v.coerceIn(MIN_WINDOW_MS, MAX_WINDOW_MS)).apply()

    var direction: DropDirection
        get() = runCatching { DropDirection.valueOf(sp.getString(KEY_DIR, null) ?: "") }
            .getOrDefault(DropDirection.OUTGOING)
        set(v) = sp.edit().putString(KEY_DIR, v.name).apply()

    // Пользователь хотел, чтобы туннель работал: нужно, чтобы отличить
    // перезапуск после убийства системой от ручной остановки.
    var wantRunning: Boolean
        get() = sp.getBoolean(KEY_WANT, false)
        set(v) = sp.edit().putBoolean(KEY_WANT, v).apply()

    var overlayX: Int
        get() = sp.getInt(KEY_X, 24)
        set(v) = sp.edit().putInt(KEY_X, v).apply()

    var overlayY: Int
        get() = sp.getInt(KEY_Y, 300)
        set(v) = sp.edit().putInt(KEY_Y, v).apply()

    companion object {
        const val MIN_WINDOW_MS = 200
        const val MAX_WINDOW_MS = 1500
        const val DEFAULT_WINDOW_MS = 600
        const val STEP_MS = 50

        private const val KEY_WINDOW = "window_ms"
        private const val KEY_DIR = "direction"
        private const val KEY_WANT = "want_running"
        private const val KEY_X = "overlay_x"
        private const val KEY_Y = "overlay_y"
    }
}
