package com.example.lagdrop.net

import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructPollfd
import android.util.Log
import com.example.lagdrop.DropGate
import java.io.FileDescriptor
import java.io.IOException
import java.net.DatagramSocket
import java.net.Socket
import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

class Protector(
    val tcp: (Socket) -> Boolean,
    val udp: (DatagramSocket) -> Boolean,
)

/**
 * Пользовательский «NAT»: пакеты из tun разбираются, TCP терминируется локально
 * (мы изображаем удалённый хост для приложения), а данные уходят в обычные
 * protect()-нутые сокеты. Без этого при пропускании пакетов интернет бы не работал —
 * tun сам по себе ничего никуда не отправляет.
 *
 * Поток reader читает tun и применяет исходящий дроп. Всё остальное (разбор, состояние
 * TCP/UDP, запись в tun) — в одном потоке worker, поэтому состояние без блокировок.
 */
class TunnelEngine(
    private val tunFd: FileDescriptor,
    val mtu: Int,
    val protector: Protector,
    val gate: DropGate,
    private val onFatal: (Throwable) -> Unit,
) {
    val selector: Selector = Selector.open()

    private val packets = ConcurrentLinkedQueue<ByteArray>()
    private val tasks = ConcurrentLinkedQueue<Runnable>()
    private val wakePending = AtomicBoolean(false)
    @Volatile private var running = false
    private var reader: Thread? = null
    private var worker: Thread? = null

    private val tcp = TcpRelay(this)
    private val udp = UdpRelay(this)

    fun start() {
        running = true
        worker = Thread({ workerLoop() }, "lagdrop-worker").also { it.start() }
        reader = Thread({ readerLoop() }, "lagdrop-reader").also { it.start() }
    }

    /** Блокирует не дольше ~1.5 с; после возврата дескриптор tun можно закрывать. */
    fun stop() {
        running = false
        selector.wakeup()
        reader?.join(1000)
        worker?.join(1000)
    }

    /** Окно дропа закончилось: надо отдать приложению удержанные TCP-данные. */
    fun resume() = post { tcp.resumeAll() }

    /** Конец окна с откатом: рвём все TCP-соединения, приложению уходит RST. */
    fun resetAll() = post { tcp.resetAll() }

    fun post(task: Runnable) {
        tasks.add(task)
        wake()
    }

    private fun wake() {
        if (wakePending.compareAndSet(false, true)) selector.wakeup()
    }

    /** Только из worker-потока. */
    fun writeTun(pkt: ByteArray) {
        var attempts = 0
        while (true) {
            try {
                Os.write(tunFd, pkt, 0, pkt.size)
                return
            } catch (e: ErrnoException) {
                val retry = e.errno == OsConstants.EAGAIN || e.errno == OsConstants.EINTR
                if (retry && attempts++ < 50) {
                    Thread.sleep(2)
                    continue
                }
                fatal(e)
                return
            }
        }
    }

    private fun fatal(t: Throwable) {
        if (!running) return
        running = false
        selector.wakeup()
        onFatal(t)
    }

    private fun readerLoop() {
        val buf = ByteArray(32767)
        val pfd = StructPollfd()
        pfd.fd = tunFd
        pfd.events = OsConstants.POLLIN.toShort()
        val arr = arrayOf(pfd)
        val bad = OsConstants.POLLERR or OsConstants.POLLHUP or OsConstants.POLLNVAL
        try {
            while (running) {
                pfd.revents = 0
                val r = try {
                    Os.poll(arr, 250) // таймаут нужен, чтобы заметить running=false
                } catch (e: ErrnoException) {
                    if (e.errno == OsConstants.EINTR) continue else throw e
                }
                if (r <= 0) continue
                val re = pfd.revents.toInt()
                if (re and bad != 0) throw IOException("tun закрыт, revents=$re")

                var count = 0
                while (running && count++ < 64) {
                    val n = try {
                        Os.read(tunFd, buf, 0, buf.size)
                    } catch (e: ErrnoException) {
                        when (e.errno) {
                            OsConstants.EAGAIN -> break
                            OsConstants.EINTR -> continue
                            else -> throw e
                        }
                    }
                    if (n <= 0) break
                    // Дроп исходящих: пакет просто не доходит до релея.
                    if (gate.dropOutbound()) { gate.outDropped.incrementAndGet(); continue }
                    gate.outPassed.incrementAndGet()
                    packets.add(buf.copyOf(n))
                }
                if (!packets.isEmpty()) wake()
            }
        } catch (t: Throwable) {
            fatal(t)
        }
    }

    private fun workerLoop() {
        var lastSweep = System.nanoTime()
        try {
            while (running) {
                selector.select(1000)
                wakePending.set(false)

                while (true) {
                    val t = tasks.poll() ?: break
                    guarded { t.run() }
                }

                var n = 0
                while (n++ < 512) {
                    val p = packets.poll() ?: break
                    guarded { handlePacket(p) }
                }
                if (!packets.isEmpty()) wake()

                val it = selector.selectedKeys().iterator()
                while (it.hasNext()) {
                    val key = it.next()
                    it.remove()
                    if (!key.isValid) continue
                    guarded { dispatch(key) }
                }

                val now = System.nanoTime()
                if (now - lastSweep > 5_000_000_000L) {
                    lastSweep = now
                    guarded { tcp.sweep(now) }
                    guarded { udp.sweep(now) }
                }
            }
        } catch (t: Throwable) {
            fatal(t)
        } finally {
            runCatching { tcp.closeAll() }
            runCatching { udp.closeAll() }
            runCatching { selector.close() }
        }
    }

    private inline fun guarded(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            // Один плохой пакет/сокет не должен валить весь туннель.
            Log.w(TAG, "ошибка обработки", e)
        }
    }

    private fun dispatch(key: SelectionKey) {
        when (val a = key.attachment()) {
            is TcpRelay.Conn -> tcp.onReady(key, a)
            is UdpRelay.Flow -> udp.onReady(a)
        }
    }

    private fun handlePacket(buf: ByteArray) {
        val ip = IpPacket.parse(buf, buf.size) ?: return
        when (ip.protocol) {
            Ip.PROTO_TCP -> if (ip.totalLen - ip.ihl >= 20) {
                val seg = TcpSegment(ip)
                if (seg.valid) tcp.onSegment(seg)
            }
            Ip.PROTO_UDP -> if (ip.totalLen - ip.ihl >= 8) {
                val dg = UdpDatagram(ip)
                if (dg.valid) udp.onDatagram(dg)
            }
            // ICMP и прочее не релеим: сырые сокеты без root недоступны.
        }
    }

    companion object {
        private const val TAG = "LagDrop"
    }
}
