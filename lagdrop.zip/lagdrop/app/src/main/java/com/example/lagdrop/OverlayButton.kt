package com.example.lagdrop

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.hypot

/** Создавать и вызывать только с main-потока. show() может бросить, если overlay-право отозвано. */
class OverlayButton(private val ctx: Context, private val prefs: Prefs) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = ctx.resources.displayMetrics.density
    private val size = (56 * density).toInt()
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    private val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private var view: TextView? = null

    private val params = WindowManager.LayoutParams(
        size, size,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private val stateListener: (Boolean) -> Unit = { active -> paint(active) }

    fun show() {
        if (view != null) return
        val dm = ctx.resources.displayMetrics
        params.x = prefs.overlayX.coerceIn(0, (dm.widthPixels - size).coerceAtLeast(0))
        params.y = prefs.overlayY.coerceIn(0, (dm.heightPixels - size).coerceAtLeast(0))

        val v = TextView(ctx).apply {
            text = ctx.getString(R.string.overlay_label)
            contentDescription = ctx.getString(R.string.overlay_desc)
            gravity = Gravity.CENTER
            textSize = 11f
            setTextColor(Color.WHITE)
            background = bg
            setOnClickListener { DropController.toggle(prefs) }
            setOnTouchListener(dragListener())
        }
        paint(DropController.isActive())
        wm.addView(v, params)
        view = v
        DropController.addListener(stateListener)
    }

    fun hide() {
        DropController.removeListener(stateListener)
        view?.let { v -> runCatching { wm.removeView(v) } }
        view = null
    }

    private fun paint(active: Boolean) {
        bg.setColor(if (active) COLOR_ACTIVE else COLOR_IDLE)
    }

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false

    private fun dragListener() = android.view.View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startX = params.x
                startY = params.y
                dragging = false
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!dragging && hypot(dx, dy) > slop) dragging = true
                if (dragging) {
                    val dm = ctx.resources.displayMetrics
                    params.x = (startX + dx.toInt()).coerceIn(0, (dm.widthPixels - size).coerceAtLeast(0))
                    params.y = (startY + dy.toInt()).coerceIn(0, (dm.heightPixels - size).coerceAtLeast(0))
                    runCatching { wm.updateViewLayout(v, params) }
                }
                true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    prefs.overlayX = params.x
                    prefs.overlayY = params.y
                } else {
                    v.performClick()
                }
                dragging = false
                true
            }
            else -> false
        }
    }

    companion object {
        private val COLOR_IDLE = Color.argb(0xCC, 0x37, 0x47, 0x4F)
        private val COLOR_ACTIVE = Color.argb(0xEE, 0xD3, 0x2F, 0x2F)
    }
}
