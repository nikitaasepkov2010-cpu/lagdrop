package com.example.lagdrop

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var statusText: TextView
    private lateinit var errorText: TextView
    private lateinit var windowLabel: TextView
    private lateinit var toggleButton: Button

    private val stateListener: () -> Unit = { render() }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            // Сервис работает и без уведомления в шторке, поэтому отказ не блокирует запуск.
            if (!granted) toast(R.string.toast_notif_denied)
            continueStart(notifAsked = true)
        }

    private val overlayLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            // resultCode у этого экрана ненадёжен — проверяем фактическое состояние.
            if (Settings.canDrawOverlays(this)) continueStart(notifAsked = true)
            else toast(R.string.toast_overlay_denied)
        }

    private val vpnLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) launchService() else toast(R.string.toast_vpn_denied)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        statusText = findViewById(R.id.statusText)
        errorText = findViewById(R.id.errorText)
        windowLabel = findViewById(R.id.windowLabel)
        toggleButton = findViewById(R.id.toggleButton)

        val seek = findViewById<SeekBar>(R.id.windowSeek)
        seek.progress = (prefs.windowMs - Prefs.MIN_WINDOW_MS) / Prefs.STEP_MS
        showWindow(prefs.windowMs)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val ms = Prefs.MIN_WINDOW_MS + progress * Prefs.STEP_MS
                prefs.windowMs = ms
                showWindow(ms)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        val group = findViewById<RadioGroup>(R.id.directionGroup)
        group.check(if (prefs.direction == DropDirection.BOTH) R.id.dirBoth else R.id.dirOutgoing)
        group.setOnCheckedChangeListener { _, id ->
            prefs.direction = if (id == R.id.dirBoth) DropDirection.BOTH else DropDirection.OUTGOING
        }

        val resetCheck = findViewById<android.widget.CheckBox>(R.id.resetCheck)
        resetCheck.isChecked = prefs.resetAtEnd
        resetCheck.setOnCheckedChangeListener { _, on -> prefs.resetAtEnd = on }

        toggleButton.setOnClickListener {
            if (TunnelState.running) {
                startService(Intent(this, LagVpnService::class.java).setAction(LagVpnService.ACTION_STOP))
            } else {
                continueStart(notifAsked = false)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        TunnelState.addListener(stateListener)
        render()
    }

    override fun onStop() {
        TunnelState.removeListener(stateListener)
        super.onStop()
    }

    private fun showWindow(ms: Int) {
        windowLabel.text = getString(R.string.settings_window, ms)
    }

    private fun render() {
        val running = TunnelState.running
        statusText.setText(if (running) R.string.status_running else R.string.status_stopped)
        toggleButton.setText(if (running) R.string.btn_stop else R.string.btn_start)
        val err = TunnelState.error
        errorText.visibility = if (err.isNullOrEmpty()) View.GONE else View.VISIBLE
        errorText.text = err
    }

    /** Последовательно добирает разрешения; каждый callback возвращается сюда. */
    private fun continueStart(notifAsked: Boolean) {
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            overlayLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val vpnIntent = VpnService.prepare(this)
        if (vpnIntent != null) {
            vpnLauncher.launch(vpnIntent)
            return
        }
        launchService()
    }

    private fun launchService() {
        ContextCompat.startForegroundService(
            this, Intent(this, LagVpnService::class.java).setAction(LagVpnService.ACTION_START)
        )
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_LONG).show()
}
